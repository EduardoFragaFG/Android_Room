package Repository.dao;

public interface UsuarioDao {
}
