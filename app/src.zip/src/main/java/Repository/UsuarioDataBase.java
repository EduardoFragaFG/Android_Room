package Repository;

public class UsuarioDataBase {
}
