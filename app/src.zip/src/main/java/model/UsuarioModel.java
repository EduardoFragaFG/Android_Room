package com.example.room.model

import androidx.room.ColumInfo
import androidx.room.Entity


@Entity(tableName = "Usuario")
class UsuarioModel{

}